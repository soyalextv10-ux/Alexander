package com.alexander.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import kotlin.concurrent.thread

class Srv(val addr: String) {
    @Volatile var host = ""
    @Volatile var mode = ""
    @Volatile var lang = ""
    @Volatile var players = 0
    @Volatile var max = 0
    @Volatile var ping = -1
    @Volatile var pass = false
    @Volatile var ok = false
}

class MainActivity : Activity() {
    // ===== Personaliza aquí =====
    private val internet = listOf("pr.sampdroid.app:7777")
    // ============================

    private val BG = Color.rgb(10, 10, 14)
    private val GOLD = Color.rgb(212, 175, 55)
    private val GOLD2 = Color.rgb(140, 108, 28)
    private val GOLDL = Color.rgb(246, 222, 140)
    private val CRIM = Color.rgb(190, 28, 44)
    private val TXT = Color.rgb(235, 228, 215)
    private val DIM = Color.rgb(150, 144, 132)

    private val nickRegex = Regex("^[A-Za-z0-9_\\[\\]\\\$=@.()]{3,20}\$")
    private val states = HashMap<String, Srv>()
    private var favs = mutableListOf<String>()
    private var tab = 1
    private lateinit var nick: EditText
    private lateinit var addr: EditText
    private lateinit var container: LinearLayout
    private lateinit var tabFav: Button
    private lateinit var tabNet: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs by lazy { getSharedPreferences("alexander", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        favs = (prefs.getString("fav", null)?.split("\n")?.filter { it.isNotBlank() } ?: internet).toMutableList()
        tab = prefs.getInt("tab", 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            fitsSystemWindows = true
        }

        // Cabecera
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        head.addView(ImageView(this).apply {
            setImageResource(R.mipmap.logo)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        })
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "Alexander"
            textSize = 30f
            setTextColor(GOLDL)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        })
        titles.addView(TextView(this).apply {
            text = "LAUNCHER  ·  LOS SANTOS"
            textSize = 11f
            letterSpacing = 0.15f
            setTextColor(GOLD)
        })
        head.addView(titles)
        root.addView(head)
        root.addView(line())

        // Nick
        nick = field("Player name (3-20)").apply {
            setText(prefs.getString("nick", "") ?: "")
            setSingleLine()
        }
        val nickRow = LinearLayout(this).apply { setPadding(dp(16), dp(12), dp(16), dp(4)) }
        nickRow.addView(nick, LinearLayout.LayoutParams(-1, -2))
        root.addView(nickRow)

        // Pestañas + refrescar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        tabFav = button("Favorites", false) { tab = 0; prefs.edit().putInt("tab", 0).apply(); render(); refresh() }
        tabNet = button("Internet", false) { tab = 1; prefs.edit().putInt("tab", 1).apply(); render(); refresh() }
        val bRef = button("↻", false) { refresh() }
        bar.addView(tabFav, weight())
        bar.addView(tabNet, weight())
        bar.addView(bRef, LinearLayout.LayoutParams(dp(56), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) })
        root.addView(bar)

        // Lista
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(12))
        }
        root.addView(ScrollView(this).apply { addView(container) }, LinearLayout.LayoutParams(-1, 0, 1f))

        // Añadir servidor
        addr = field("ip o dominio:puerto").apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            gravity = Gravity.CENTER_VERTICAL
        }
        addRow.addView(addr, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        addRow.addView(button("Add", true) { addServer() }, LinearLayout.LayoutParams(dp(80), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) })
        root.addView(line())
        root.addView(addRow)

        setContentView(root)
        render()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("nick", nick.text.toString().trim()).apply()
    }

    // ===== UI helpers =====
    private fun weight() = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(4), 0, dp(4), 0) }

    private fun line() = View(this).apply {
        setBackgroundColor(GOLD)
        layoutParams = LinearLayout.LayoutParams(-1, dp(2))
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(DIM)
        setTextColor(TXT)
        textSize = 15f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            setColor(Color.rgb(22, 21, 28)); cornerRadius = dp(8).toFloat(); setStroke(dp(1), GOLD2)
        }
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 12f
        minHeight = 0; minimumHeight = 0
        setPadding(dp(8), 0, dp(8), 0)
        setTextColor(if (primary) Color.WHITE else GOLD)
        background = GradientDrawable().apply {
            setColor(if (primary) CRIM else Color.rgb(34, 31, 28))
            cornerRadius = dp(10).toFloat(); setStroke(dp(1), GOLD)
        }
        setOnClickListener { onClick() }
    }

    private fun current(): List<String> = if (tab == 0) favs else internet

    private fun render() {
        tabFav.setTextColor(if (tab == 0) GOLDL else DIM)
        tabNet.setTextColor(if (tab == 1) GOLDL else DIM)
        container.removeAllViews()
        val list = current()
        if (list.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Aún no tienes favoritos. Añade un servidor con IP:puerto."
                setTextColor(DIM); gravity = Gravity.CENTER; setPadding(dp(16), dp(32), dp(16), dp(32))
            })
            return
        }
        for (a in list) container.addView(card(a))
    }

    private fun card(a: String): View {
        val s = states.getOrPut(a) { Srv(a) }
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.rgb(24, 22, 28)); cornerRadius = dp(12).toFloat(); setStroke(dp(1), GOLD2)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
        }
        c.addView(TextView(this).apply {
            text = if (s.ok) (if (s.pass) "[Password] " else "") + s.host else a
            setTextColor(GOLDL); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        })
        val info = if (s.ok) "${s.players} / ${s.max}   ·   ${s.ping} ms   ·   ${s.mode}   ·   ${s.lang}" else "Sin respuesta (o consultando…)"
        c.addView(TextView(this).apply {
            text = info; setTextColor(if (s.ok) pingColor(s.ping) else DIM); textSize = 13f
            setPadding(0, dp(4), 0, 0)
        })
        c.addView(TextView(this).apply {
            text = a; setTextColor(DIM); textSize = 12f; typeface = Typeface.MONOSPACE
            setPadding(0, dp(2), 0, dp(10))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Connect", true) { connect(a) }, weight())
        row.addView(button("Copy", false) { copy(a); toast("Copiado: $a") }, weight())
        if (tab == 0) {
            row.addView(button("Delete", false) {
                favs.remove(a); saveFavs(); render()
            }, weight())
        } else if (!favs.contains(a)) {
            row.addView(button("★", false) {
                favs.add(a); saveFavs(); toast("Guardado en Favorites"); render()
            }, weight())
        }
        c.addView(row)
        return c
    }

    private fun pingColor(ms: Int) = when {
        ms < 90 -> Color.rgb(110, 220, 120)
        ms < 160 -> Color.rgb(240, 200, 80)
        else -> Color.rgb(240, 90, 90)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun saveFavs() = prefs.edit().putString("fav", favs.joinToString("\n")).apply()

    private fun copy(t: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("server", t))
    }

    // ===== Acciones =====
    private fun addServer() {
        val raw = addr.text.toString()
        val sp = split(raw)
        if (sp == null) { toast("Dirección inválida. Ej: 127.0.0.1:7777"); return }
        val a = "${sp.first}:${sp.second}"
        if (!favs.contains(a)) favs.add(a)
        saveFavs()
        addr.setText("")
        tab = 0
        render(); refresh()
    }

    private fun connect(a: String) {
        val n = nick.text.toString().trim()
        if (!nickRegex.matches(n)) { toast("Escribe un nick válido (3-20 caracteres)"); return }
        prefs.edit().putString("nick", n).apply()
        copy(a)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("samp://$a")))
        } catch (e: ActivityNotFoundException) {
            toast("IP copiada: $a. Pégala en tu cliente de SA-MP.")
        }
    }

    private fun refresh() {
        for (a in current()) {
            val s = states.getOrPut(a) { Srv(a) }
            thread {
                query(s)
                runOnUiThread { if (!isFinishing) render() }
            }
        }
    }

    // ===== Consulta UDP (protocolo SA-MP) =====
    private fun split(text: String): Pair<String, Int>? {
        val t = text.trim()
        val i = t.lastIndexOf(':')
        var h = t
        var p = 7777
        if (i > 0) {
            h = t.substring(0, i)
            p = t.substring(i + 1).toIntOrNull() ?: return null
        }
        if (!Regex("[A-Za-z0-9.\\-]+").matches(h) || p !in 1..65535) return null
        return Pair(h, p)
    }

    private fun query(s: Srv) {
        try {
            val sp = split(s.addr) ?: run { s.ok = false; return }
            val ip = InetAddress.getAllByName(sp.first).first { it is Inet4Address }
            val port = sp.second
            val pk = ByteArray(11)
            "SAMP".toByteArray(Charsets.US_ASCII).copyInto(pk)
            ip.address.copyInto(pk, 4)
            pk[8] = (port and 0xFF).toByte()
            pk[9] = ((port shr 8) and 0xFF).toByte()
            pk[10] = 'i'.code.toByte()
            DatagramSocket().use { sock ->
                sock.soTimeout = 2000
                val t0 = System.nanoTime()
                sock.send(DatagramPacket(pk, pk.size, ip, port))
                val buf = ByteArray(2048)
                val r = DatagramPacket(buf, buf.size)
                sock.receive(r)
                val ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
                if (r.length < 20) { s.ok = false; s.ping = -1; return }
                val bb = ByteBuffer.wrap(buf, 0, r.length).order(ByteOrder.LITTLE_ENDIAN)
                bb.position(11)
                val pass = bb.get().toInt() != 0
                val pl = bb.short.toInt() and 0xFFFF
                val mx = bb.short.toInt() and 0xFFFF
                val cs = Charset.forName("windows-1252")
                fun str(): String {
                    val n = bb.int
                    if (n < 0 || n > bb.remaining()) return ""
                    val arr = ByteArray(n)
                    bb.get(arr)
                    return String(arr, cs)
                }
                s.host = str(); s.mode = str(); s.lang = str()
                s.pass = pass; s.players = pl; s.max = mx; s.ping = ms; s.ok = true
            }
        } catch (e: Exception) {
            s.ok = false; s.ping = -1
        }
    }
}
